-----

<p align= "center">
  <kbd>
    <img  src="https://raw.githubusercontent.com/waxnet/NetWare/main/.github/workflows/icon.png">
  </kbd>
</p>

-----

### <p align="center">🕸️ NetWare 🕸️</p>
<p align= "center">
  <img src="https://img.shields.io/github/stars/waxnet/NetWare">
  <img src="https://img.shields.io/github/forks/waxnet/NetWare">
  <br>
  <img src="https://img.shields.io/github/last-commit/waxnet/NetWare">
  <img src="https://img.shields.io/github/license/waxnet/NetWare">
  <br>
  <img src="https://img.shields.io/github/downloads/waxnet/NetWare/total.svg">
</p>

-----

### <p align="center">🔑 Usage 🔑</p>
<p align="center"><i><b>
After you've downloaded and extracted the latest release, open 1v1.LOL
and run "inject.cmd" to load NetWare.
</b></i></p>

-----

### <p align="center">📜 Features 📜</p>

```
• Combat
      + Aimbot
            - Enabled
            - Aim Bone
            - Aim Mode
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - Smoothing (5 - 10)
            - FOV Color Picker
      + Silent Aim
            - Enabled
            - Aim Bone
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - FOV Color Picker
      + Weapons
            - No Recoil
            - Infinite Ammo
            - Rapid Fire

• Visual
      + ESP
            - Tracers
            - Skeleton
            - 3D Boxes
            - 2D Boxes
            - Info
            - Nametags
            - Background Color Picker
            - Teammate Color Picker
            - Enemy Color Picker
            - Bot Color Picker
      + FOV Changer
            - Enabled
            - Amount (20 - 150)

• Movement
      + Speed
            - Enabled
            - Amount (1 - 10)
      + Fly
            - Enabled
      + BHop
            - Enabled

• Exploits
      + Player
            - Godmode
            - Instant Land
            - Infinite Materials
            - Anti Freeze
      + Gameplay
            - Leave Game
            - Auto Play
      + Locker
            - Unlock Emotes
            - Unlock Stickers
            - Skin Changer
            - Pickaxe Changer
      + Game
            - Force Win
            - Kill All
            - Freeze Players
            - Destroy Buildings
            - Open Crates
            - Building Spam
            - Rig Spam
            - Instant Break
      + Fun
            - Add 10k Fake Gold
            - Add 10k Fake Gems
            - Loadout Level Changer

• Settings
      + Config Manager
            - Save
            - Delete
      + Interface
            - Watermark
            - Watermark Time Type
      + Config Loader
```

-----

### <p align="center">💡 Ideas 💡</p>

    • Fix my shitty code.

<p align="center"><i><b>Feel free to submit any idea by making a pull request on this repository!</b></i></p>

-----

### <p align="center">💾 Dependencies 💾</p>
<p align="center"><a href="https://github.com/warbler/SharpMonoInjector">SharpMonoInjector</a></p>

-----

### <p align="center">⚠️ Disclaimer ⚠️</p>

<p align="center"><i><b>This program is meant for educational purposes only.</b></i></p>

-----

### <p align="center"><a href="https://github.com/waxnet">waxnet</a></p>
